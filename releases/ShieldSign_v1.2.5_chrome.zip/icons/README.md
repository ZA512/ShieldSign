# Icônes ShieldSign

Ce dossier doit contenir les icônes de l'extension aux formats suivants :

- `icon16.png` - 16x16 pixels
- `icon32.png` - 32x32 pixels
- `icon48.png` - 48x48 pixels
- `icon128.png` - 128x128 pixels

## Recommandations

- Utiliser un fond transparent
- Design simple et reconnaissable (bouclier avec logo)
- Couleur principale : #667eea (violet/bleu)
- Format PNG avec transparence alpha
